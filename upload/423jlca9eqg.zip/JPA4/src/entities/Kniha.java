package entities;

import javax.persistence.*;

@Entity
public class Kniha {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", nullable = false)
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Kniha kniha = (Kniha) o;

		return id != null && id.equals(kniha.id);
	}

	@Override
	public int hashCode() {
		return 256420631;
	}
}
