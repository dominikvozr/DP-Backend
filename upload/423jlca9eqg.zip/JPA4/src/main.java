import javax.persistence.*;

public class main {

	@PrePersist
	void prePersist(Object object) {
	}

	@PreUpdate
	void preUpdate(Object object) {
	}

	@PreRemove
	void preRemove(Object object) {
	}

	@PostLoad
	void postLoad(Object object) {
	}

	@PostRemove
	void postRemove(Object object) {
	}

	@PostUpdate
	void postUpdate(Object object) {
	}

	@PostPersist
	void postPersist(Object object) {
	}

	public static void main(String[] args) {

	}

}
